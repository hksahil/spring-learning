package com.nexttry.newtry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewtryApplicationTests {

	@Test
	void contextLoads() {
	}

}
