package com.nexttry.newtry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewtryApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewtryApplication.class, args);
	}

}
